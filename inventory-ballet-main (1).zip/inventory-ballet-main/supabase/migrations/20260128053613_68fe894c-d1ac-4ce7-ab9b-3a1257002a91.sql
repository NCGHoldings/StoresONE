-- Drop the misconfigured anon policy
DROP POLICY IF EXISTS "Anon inserts: manager or procurement only" 
  ON public.inventory_batches;

-- Add proper INSERT policy for authenticated users
-- Matches pattern used by inventory and inventory_transactions tables
CREATE POLICY "Warehouse can insert inventory_batches" 
  ON public.inventory_batches 
  FOR INSERT 
  TO authenticated
  WITH CHECK (
    has_any_role(
      (SELECT auth.uid()), 
      ARRAY['admin'::app_role, 'warehouse_manager'::app_role, 'procurement'::app_role]
    )
  );