-- Fix the root cause: reserved_quantity should not exceed quantity
-- This will automatically fix available_quantity since it's a generated column
UPDATE public.inventory 
SET reserved_quantity = LEAST(COALESCE(reserved_quantity, 0), COALESCE(quantity, 0))
WHERE COALESCE(reserved_quantity, 0) > COALESCE(quantity, 0);

-- Ensure quantity is never negative
UPDATE public.inventory 
SET quantity = 0 
WHERE quantity < 0;

-- Ensure reserved_quantity is never negative
UPDATE public.inventory 
SET reserved_quantity = 0 
WHERE reserved_quantity < 0;

-- Now add CHECK constraints to prevent negative stock values on base columns
ALTER TABLE public.inventory 
  ADD CONSTRAINT inventory_quantity_non_negative 
  CHECK (quantity >= 0);

ALTER TABLE public.inventory 
  ADD CONSTRAINT inventory_reserved_quantity_non_negative 
  CHECK (reserved_quantity >= 0);

-- Add constraint to ensure reserved cannot exceed quantity
ALTER TABLE public.inventory 
  ADD CONSTRAINT inventory_reserved_not_exceed_quantity 
  CHECK (reserved_quantity <= quantity);

-- Add constraint to inventory_batches
ALTER TABLE public.inventory_batches 
  ADD CONSTRAINT inventory_batches_quantity_non_negative 
  CHECK (current_quantity >= 0);