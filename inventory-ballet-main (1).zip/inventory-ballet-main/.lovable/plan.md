
# Fix RLS Policy for inventory_batches Table

## Problem Identified

The `inventory_batches` table has a misconfigured RLS policy that prevents authenticated users from creating batches:

| Current Policy | Issue |
|----------------|-------|
| "Anon inserts: manager or procurement only" | Applied to `anon` role instead of `authenticated` |

This means when a logged-in user (warehouse manager or procurement) tries to create a batch during Goods Receipt, it fails with "new row violates row-level security policy".

## Root Cause

The INSERT policy was created for the wrong role:
- **Current**: `GRANT INSERT TO anon` with check for app_role
- **Should be**: `GRANT INSERT TO authenticated` with role check

## Solution

Create a new migration to:
1. Drop the incorrectly configured anon INSERT policy
2. Add a proper INSERT policy for authenticated users using the `has_any_role` function (consistent with other inventory tables)

## Database Migration

```sql
-- Drop the misconfigured anon policy
DROP POLICY IF EXISTS "Anon inserts: manager or procurement only" 
  ON public.inventory_batches;

-- Add proper INSERT policy for authenticated users
-- Matches pattern used by inventory and inventory_transactions tables
CREATE POLICY "Warehouse can insert inventory_batches" 
  ON public.inventory_batches 
  FOR INSERT 
  TO authenticated
  WITH CHECK (
    has_any_role(
      (SELECT auth.uid()), 
      ARRAY['admin'::app_role, 'warehouse_manager'::app_role, 'procurement'::app_role]
    )
  );
```

## Policy Comparison (After Fix)

| Table | INSERT Policy | Allowed Roles |
|-------|---------------|---------------|
| `inventory` | `has_any_role(..., admin, warehouse_manager)` | admin, warehouse_manager |
| `inventory_transactions` | `has_any_role(..., admin, warehouse_manager)` | admin, warehouse_manager |
| `inventory_batches` | `has_any_role(..., admin, warehouse_manager, procurement)` | admin, warehouse_manager, procurement |

Adding `procurement` role is appropriate since Goods Receipt is a procurement workflow.

## Files to Create/Modify

| File | Action |
|------|--------|
| `supabase/migrations/[timestamp]_fix_inventory_batches_insert_policy.sql` | New migration |

## Expected Outcome

After applying this fix:
- Warehouse managers can create batches during Goods Receipt
- Procurement users can create batches during Goods Receipt
- Admins can create batches
- Anonymous users cannot create batches (security preserved)
- The Goods Receipt dialog will work correctly for batch-tracked products
